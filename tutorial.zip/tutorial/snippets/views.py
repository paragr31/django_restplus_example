# -*- coding: utf-8 -*-
from rest_framework import viewsets
from django.http import HttpResponse, JsonResponse
from rest_framework.decorators import detail_route
from rest_framework.response import Response
from .models import Snippet
from django.contrib.auth.models import User
from .serializers import SnippetSerializer, UserSerializer, TestSerializer
from rest_framework import permissions
from .permissions import IsOwnerOrReadOnly
from rest_framework import renderers
from django.contrib.auth.mixins import LoginRequiredMixin
from rest_framework_tracking.mixins import LoggingMixin
from rest_framework.generics import GenericAPIView
from rest_framework import status
from rest_framework.parsers import JSONParser,FormParser
from rest_framework.renderers import JSONRenderer, BrowsableAPIRenderer
from django.views.decorators.csrf import csrf_exempt
import json
import logging
logger = logging.getLogger('django')


class TestMyView(GenericAPIView):
    """
    This viewset will use the post method with generic serializer
    """
    serializer_class = TestSerializer
    parser_classes = (JSONParser,FormParser,)
    renderer_classes = (BrowsableAPIRenderer,JSONRenderer,)
    
    @csrf_exempt
    def post(self, request, format=None):
        logger.info("request = ** %s"%(dir(request)))
        data = JSONParser().parse(request)
        logger.info("data = ** %s" %(data))
        serializer = TestSerializer(data=data)
        if serializer.is_valid():
            return JsonResponse(serializer.data, status=status.HTTP_201_CREATED)
        return JsonResponse(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class UserViewSet(LoggingMixin,viewsets.ReadOnlyModelViewSet):
    """
    This viewset automatically provides 'list' and 'detail' actions.
    """
    queryset = User.objects.all()
    serializer_class = UserSerializer


class SnippetViewSet(LoggingMixin,LoginRequiredMixin, viewsets.ModelViewSet):
    """
    This viewset automatically provides 'list', 'create', 'retrieve',
    'update' and 'destroy' actions.
    """
    queryset = Snippet.objects.all()
    serializer_class = SnippetSerializer
    permission_classes = (permissions.IsAuthenticated,
                          IsOwnerOrReadOnly,)

    @detail_route(renderer_classes=[renderers.StaticHTMLRenderer])
    def highlight(self, request, *args, **kwargs):
        snippet = self.get_object()
        return Response(snippet.highlighted)

    def perform_create(self, serializer):
        serializer.save(owner=self.request.user)
